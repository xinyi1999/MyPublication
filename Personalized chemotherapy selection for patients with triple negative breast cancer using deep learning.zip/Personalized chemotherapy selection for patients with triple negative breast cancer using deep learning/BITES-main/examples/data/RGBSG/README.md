## Data Description

The RGBSG dataset can be obtained from https://github.com/arturomoncadatorres/deepsurvk/tree/master/deepsurvk/datasets/data.
To use the example files place `rgbsg.h5` in this folder.

Alternatively the raw data can be obtained from ``CRAN`` ([GBSG](https://rdrr.io/cran/survival/man/gbsg.html) and [Rotterdam](https://rdrr.io/cran/survival/man/rotterdam.html))
