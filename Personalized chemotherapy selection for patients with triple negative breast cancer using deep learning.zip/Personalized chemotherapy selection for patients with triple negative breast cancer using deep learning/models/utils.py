import numpy as np
import pandas as pd
import torch
from auton_survival import metrics
from lifelines.utils import concordance_index
from sklearn.metrics._ranking import auc
from sksurv.ensemble import RandomSurvivalForest
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.metrics import integrated_brier_score, cumulative_dynamic_auc
from sklearn.utils import shuffle

def exists(val):
    return val is not None


def default(val, d):
    return val if exists(val) else d


def pair(val):
    return (val, val) if not isinstance(val, tuple) else val


def get_unique_categorical_counts(root, cont_count=2, target_number=2):
    dataset = pd.read_csv(root)
    return dataset.iloc[:, 0:-(cont_count + target_number)].nunique().to_list()


def __get_restricted_area(km_estimate, horizon):
    """Compute area under the Kaplan Meier curve (mean survival time) restricted by a specified
    time horizion.

    Parameters
    -----------
    km_estimate : Fitted Kaplan Meier estimator.
    horizon : float
        The time horizon at which to compare the survival curves.
        Must be specified for metric 'restricted_mean' and 'survival_at'.
        For 'hazard_ratio' this is ignored.

    Returns
    -----------
    float : Area under the Kaplan Meier curve (mean survival time).
    @ : KM_estimate is a pd.Dataframe, e.g. model.predict_surv_df
    """

    # x = km_estimate.survival_function_.index.values
    x = km_estimate.index
    # horizon_list = [horizon for i in range(len(x))]
    idx = [i < horizon for i in x]
    # y = km_estimate.survival_function_.KM_estimate.values[idx].tolist()
    y = km_estimate.values[idx]
    # y = y + [float(km_estimate.iloc[:, i][find_nearest_index(km_estimate.index.values, horizon)])]
    ite = auc(x[idx], y)  # sklearn.metrics._ranking.auc
    return ite


def get_ITE_byRMST(model, X, treatment, best_treatment=None, death_probability=0.5, time_horizon=60):
    if not model.baseline_hazards_:
        print('Compute Baseline Hazards before running get_ITE()')
        return


    surv0, surv1 = model.predict_surv_df(X, treatment)  # actual situation
    surv0_cf, surv1_cf = model.predict_surv_counterfactual_df(X, treatment)  # "What if" situation

    """Find factual and counterfactual prediction: Value at 50% survival probability"""
    pred0 = np.zeros(surv0.shape[1])
    pred0_cf = np.zeros(surv0.shape[1])
    # for i in range(surv0.shape[1]):
    #     pred0[i] = surv0.axes[0][find_nearest_index(surv0.iloc[:, i].values, death_probability)]   # median survival time
    #     pred0_cf[i] = surv0_cf.axes[0][find_nearest_index(surv0_cf.iloc[:, i].values, death_probability)]
    # ITE0 = pred0_cf - pred0
    for i in range(surv0.shape[1]):  # each sample
        pred0[i] = __get_restricted_area(surv0.iloc[:, i], horizon=time_horizon)
        pred0_cf[i] = __get_restricted_area(surv0_cf.iloc[:, i], horizon=time_horizon)
    ITE0 = pred0_cf - pred0
    pred1 = np.zeros(surv1.shape[1])
    pred1_cf = np.zeros(surv1.shape[1])
    # for i in range(surv1.shape[1]):
    #     pred1[i] = surv1.axes[0][find_nearest_index(surv1.iloc[:, i].values, death_probability)]
    #     pred1_cf[i] = surv1_cf.axes[0][find_nearest_index(surv1_cf.iloc[:, i].values, death_probability)]
    # ITE1 = pred1 - pred1_cf
    for i in range(surv0.shape[1]):
        pred1[i] = __get_restricted_area(surv1.iloc[:, i], horizon=time_horizon)
        pred1_cf[i] = __get_restricted_area(surv1_cf.iloc[:, i], horizon=time_horizon)
    ITE1 = pred1 - pred1_cf
    ITE = np.zeros(X.shape[0])
    k, j = 0, 0
    for i in range(X.shape[0]):
        if treatment[i] == 0:
            ITE[i] = ITE0[k]
            k = k + 1
        else:
            ITE[i] = ITE1[j]
            j = j + 1

    correct_predicted_probability = None
    if best_treatment is not None:
        correct_predicted_probability = np.sum(best_treatment == (ITE > 0) * 1) / best_treatment.shape[0]
        print('Fraction best choice: ' + str(correct_predicted_probability))

    return ITE, correct_predicted_probability

def get_ITEbyrmstfordeepsurv(model0, model1, X, treatment, best_treatment=None, time_horizon=60.):
    mask0 = treatment == 0
    mask1 = treatment == 1
    X0 = X[mask0]
    X1 = X[mask1]
    surv0 = model0.predict_surv_df(X0)
    surv0_cf = model1.predict_surv_df(X0)
    surv1 = model1.predict_surv_df(X1)
    surv1_cf = model0.predict_surv_df(X1)

    """Find factual and counterfactual prediction: Value at 50% survival probability"""
    pred0 = np.zeros(surv0.shape[1])
    pred0_cf = np.zeros(surv0.shape[1])
    for i in range(surv0.shape[1]):
        pred0[i] = __get_restricted_area(surv0.iloc[:, i], horizon=time_horizon)
        pred0_cf[i] = __get_restricted_area(surv0_cf.iloc[:, i], horizon=time_horizon)
    ITE0 = pred0_cf - pred0

    pred1 = np.zeros(surv1.shape[1])
    pred1_cf = np.zeros(surv1.shape[1])
    for i in range(surv1.shape[1]):
        pred1[i] = __get_restricted_area(surv1.iloc[:, i], horizon=time_horizon)
        pred1_cf[i] = __get_restricted_area(surv1_cf.iloc[:, i], horizon=time_horizon)
    ITE1 = pred1 - pred1_cf

    ITE = np.zeros(X.shape[0])
    k, j = 0, 0
    for i in range(X.shape[0]):
        if treatment[i] == 0:
            ITE[i] = ITE0[k]
            k = k + 1
        else:
            ITE[i] = ITE1[j]
            j = j + 1

    correct_predicted_probability=None
    if best_treatment is not None:
        correct_predicted_probability=np.sum(best_treatment==(ITE>0)*1)/best_treatment.shape[0]
        print('Fraction best choice: ' + str(correct_predicted_probability))

    return ITE, correct_predicted_probability




def make_loadertodata(dataloader, treatment=False):
    """ [x, time, treatment, event], treatment=False -> [x, time, event] """
    if treatment:
        x, d, t, e = [], [], [], []
        for i in dataloader:
            x.append(i[0])
            d.append(i[1])
            t.append(i[2])
            e.append(i[3])
        x, d, t, e = torch.cat(x), torch.cat(d), torch.cat(t), torch.cat(e)
        return x, d, t, e
    else:
        x, d, e = [], [], []
        for i in dataloader:
            x.append(i[0])
            d.append(i[1])
            e.append(i[2])
        x, d, e = torch.cat(x), torch.cat(d), torch.cat(e)
        return x, d, e


def df_totrain(df, target=['time', 'event', 'treatment']):
    if len(target) == 3:
        df = df.fillna(df.median())
        X = df.drop(columns=target).values
        Y = df[target[0]].values
        E = df[target[1]].values
        T = df[target[2]].values
        return torch.Tensor(X), torch.Tensor(Y), torch.Tensor(T), torch.Tensor(E)
    elif len(target) == 2:
        df = df.fillna(df.median())
        X = df.drop(columns=target).values
        Y = df[target[0]].values
        E = df[target[1]].values
        return torch.Tensor(X), torch.Tensor(Y), torch.Tensor(E)

def deepsurv_dftotrain(df, target=['time', 'event', 'treatment']):
    """ df = df_test
    separately return t=0 and t=1 """
    assert len(target) == 3
    df = df.fillna(df.median())
    X = df.drop(columns=target).values
    T = df[target[2]].values
    df0, df1 = df[df[target[2]] == 0], df[df[target[2]] == 1]
    X0, X1 = df0.drop(columns=target).values, df1.drop(columns=target).values
    E0, E1 = df0[target[1]].values, df1[target[1]].values
    Y0, Y1 = df0[target[0]].values, df1[target[0]].values
    return torch.Tensor(X0), torch.Tensor(Y0), torch.Tensor(E0), torch.Tensor(X1), torch.Tensor(Y1), \
           torch.Tensor(E1), torch.Tensor(X), torch.Tensor(T)

def save_rec(ITE, df, save_path='gbm_rec.csv', save=False):
    """ save a dataframe with rec
    and calculate ITE """
    df = df.reset_index(drop=True)  # frac后必须reset_index
    rec = []
    for i in range(len(ITE)):
        if ITE[i] > 0 and df['treatment'][i] == 1:
            r = True
        elif ITE[i] <= 0 and df['treatment'][i] == 0:
            r = True
        else:
            r = False
        rec.append(r)

    RMST = metrics.survival_diff_metric(metric='restricted_mean', outcomes=df,
                                        treatment_indicator=np.asarray(rec), horizon=60.)  # rmst1 - rmst0
    survival_at = metrics.survival_diff_metric(metric='survival_at', outcomes=df,
                                               treatment_indicator=np.asarray(rec), horizon=60.)
    print(f'RMST is: {RMST}, survival at time is: {survival_at}')

    if save:
        ITE = pd.DataFrame(ITE)
        df_new = pd.concat([df, ITE], axis=1)
        df_new.to_csv(save_path, index=False)

        print(f'Successfully restore csv_file with recommendation in {save_path}')


def preprocess_fordeepsurv(root, target, frac=0.2, seed=18, treatment=None):
    """ target = ['time', 'event', 'treatment'] """
    assert len(target) == 3
    df = pd.read_csv(root)
    df = df.fillna(df.median())
    df_val = df.sample(frac=frac, random_state=seed)
    df_train = df.drop(df_val.index)
    df_train, df_val = df_train[df_train[target[2]] == treatment], df_val[df_val[target[2]] == treatment]
    time_train, time_val = df_train[target[0]].values, df_val[target[0]].values
    event_train, event_val = df_train[target[1]].values, df_val[target[1]].values
    X_train, X_val = df_train.drop(columns=target).values, df_val.drop(columns=target).values
    return time_train, event_train, time_val, event_val, X_train, X_val, df_train, df_val

def preprocess_fortotal(root, target, frac=0.2, seed=18):
    """ target = ['time', 'event'] """
    assert len(target) == 2
    df = pd.read_csv(root)
    df = df.fillna(df.median())
    df_val = df.sample(frac=frac, random_state=seed)
    df_train = df.drop(df_val.index)
    time_train, time_val = df_train[target[0]].values, df_val[target[0]].values
    event_train, event_val = df_train[target[1]].values, df_val[target[1]].values
    X_train, X_val = df_train.drop(columns=target).values, df_val.drop(columns=target).values
    return time_train, event_train, time_val, event_val, X_train, X_val, df_train, df_val



def preprocess_forbsgt(root, target, split=True, frac=0.2, seed=18):
    """ target = ['time', 'event', 'treatment'] """
    assert len(target) == 3
    df = pd.read_csv(root)
    df = shuffle(df,random_state=seed)
    df = df.fillna(df.median())
    if split:
        df_val = df.sample(frac=frac, random_state=seed)
        df_train = df.drop(df_val.index)
        time_train, time_val = df_train[target[0]].values, df_val[target[0]].values
        event_train, event_val = df_train[target[1]].values, df_val[target[1]].values
        treatment_train, treatment_val = df_train[target[-1]].values, df_val[target[-1]].values
        X_train, X_val = df_train.drop(columns=target).values, df_val.drop(columns=target).values
        return time_train, event_train, treatment_train, time_val, event_val, treatment_val, X_train, X_val, df_train, df_val
    else:
        time = df[target[0]].values
        event = df[target[1]].values
        treatment = df[target[-1]].values
        X = df.drop(columns=target).values
        return time, event, treatment, X


def preprocess_forcph(root, target, split=True, frac=0.2, seed=18):
    """ target = ['time', 'event'] """
    df = pd.read_csv(root)
    df = df.fillna(df.median())
    print('Notice: preprocess_forcph() returns pd.dataframe')
    if split:
        df_val = df.sample(frac=frac, random_state=seed)
        df_train = df.drop(df_val.index)
        return df_train, df_val
    else:
        print('We train cox on training set to evaluate performance, it returns total dataset, e.g.: split = True')
        return df


def evaluate_cox(model, df_test, duration, event, boost_trap=True):
    print(concordance_index(df_test[duration], -model.predict_partial_hazard(df_test.drop(columns=[duration, event])),
                            df_test[event]))

    def bootstrap_c(model, df_test, duration, event, nsamples=1000):
        c_value = []
        for b in range(nsamples):
            # idx = np.random.randint(df_test.shape[0], size=df_test.shape[0])
            df_bt = df_test.sample(frac=0.5)
            c_bt = concordance_index(df_bt[duration],
                                     -model.predict_partial_hazard(df_bt.drop(columns=[duration, event])),
                                     df_bt[event])
            c_value.append(c_bt)
        print('95% CI of COX:', np.percentile(c_value, (2.5, 97.5)))

    if boost_trap:
        bootstrap_c(model, df_test, duration, event)

def sksurv_getsurvivaldf(X_val, X_train=None, y_train=None, model='cph'):
    """ X_train / X_val is a pd.Dataframe contains covariates
    y_train/y_val is a Surv object e.g. Surv("event", "time", df) """

    if model in ['cph', 'rsf']:   # cox & random survival forest
        if model == 'cph':
            model = CoxPHSurvivalAnalysis()
        elif model == 'rsf':
            model =  RandomSurvivalForest(random_state=18)
        model.fit(X_train, y_train)
    a = model.predict_survival_function(X_val)  # [num_samples, ]
    survival_p = []
    for i, each in enumerate(a):
        survival_p.append(each.y)
    survival_p = list(map(list, zip(*survival_p)))  # 转置
    time_index = pd.Series(a[0].x, name='time')
    survival_p = pd.DataFrame(survival_p).set_index(time_index)
    return survival_p



def skurv_evaluate(model, X_train, y_train, X_val, y_val, model_name='CPH', time_points=[10, 20, 30, 40, 50, 60]):
    """ auc at given time points and mean aucs
    compute C-index and integrated_brier_score """
    model.fit(X_train, y_train)
    c_index = model.score(X_val, y_val)
    lower, upper = np.percentile(y_val["time"], [10, 90])
    times = np.arange(lower, upper + 1)
    surv_prob = np.row_stack([
        fn(times)
        for fn in model.predict_survival_function(X_val)
    ])
    brier = integrated_brier_score(y_train, y_val, surv_prob, times)
    chf_funcs = model.predict_cumulative_hazard_function(X_val)

    risk_scores = np.row_stack([
        chf(time_points) for chf in chf_funcs
    ])
    aucs, mean_auc = cumulative_dynamic_auc(
        y_train, y_val, risk_scores, time_points
    )
    print(f'{str(model)} C-index: {c_index}, integrated_brier_score: {brier}, mean auc: {mean_auc}')
    print(f'auc at time points of {time_points} is {aucs}')


class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""

    def __init__(self, save_path, patience=4, verbose=False, delta=0):
        """
        Args:
            save_path : 模型保存文件夹
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement.
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
        """
        self.save_path = save_path
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Saves model when validation loss decrease.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        # path = os.path.join(self.save_path, 'best_network.pth')
        torch.save(model.state_dict(), self.save_path)  # 这里会存储迄今最优模型的参数
        self.val_loss_min = val_loss
