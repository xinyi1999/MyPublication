import torch

from models.BSL import BSL
from models.bites.analyse.analyse_utils import analyse_randomized_test_set
from utils.ITE import get_ITE_BITES


# This repository includes the Python codes for all models, individual treatment effect (ITE) calculation,
# and SurvSHAP(t) documented in our manuscript.
# The authors of the manuscript modified the codes provided in previous studies.
# All original codes or methods were properly cited.
# The authors of this study thank these researchers for open sourcing their codes.


if __name__ == '__main__':
    batch_size = 32   # Let's say the batch size was 32, the number of feature was 120
    num_features = 120

    X = torch.randn(batch_size, num_features)    # We mimic an input features of one batch
    # We mimic patients treatment plan, event, and follow-up time
    treatment, event, time = torch.randint(0, 2, (batch_size,)) ,\
        torch.randint(0, 2, (batch_size,)), torch.randint(0, 120, (batch_size,))

    model = BSL(X.shape[1], [128, 100], [100, 64], 1)   # Now, we initialized a BSL model with three layer,
    # while the hidden nodes was (128, 100, 64)

    model.compute_baseline_hazards(input=X, target=[time, event, treatment])   # compute the treatment-specific baseline hazards
    ITE, correct_predicted_probability = get_ITE_BITES(model, X, treatment, method='rmst', time_horizon=119)   # compute the ITE with RST method

    analyse_randomized_test_set(ITE, time.numpy(),
                                event.numpy(),
                                treatment.numpy(), method_name='Treatment 1')   # visualize the comparison between Consis. and Inconsis.
    