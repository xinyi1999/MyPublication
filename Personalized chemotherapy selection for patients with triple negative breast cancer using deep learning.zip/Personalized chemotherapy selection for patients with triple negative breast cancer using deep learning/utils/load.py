import pandas as pd
import torch
from sksurv.ensemble import RandomSurvivalForest
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.util import Surv


def split_df(df, frac=.2, seed=18, path_train=None, path_val=None):
    if isinstance(df, str):
        df = pd.read_csv(df)
    df_val = df.sample(frac=frac, random_state=seed)
    df_train = df.drop(df_val.index)
    if path_train is not None and path_val is not None:
        df_train.to_csv(path_train, index=False)
        df_val.to_csv(path_val, index=False)
        print(f'Successfully restored df_train to {path_train}, df_val to {path_val}')


def df_totrain(df, target=['time', 'event', 'treatment']):
    """ for dl models """
    if len(target) == 3:
        df = df.fillna(df.median())
        X = df.drop(columns=target).values
        Y = df[target[0]].values
        E = df[target[1]].values
        T = df[target[2]].values
        return torch.Tensor(X), torch.Tensor(Y), torch.Tensor(T), torch.Tensor(E)
    elif len(target) == 2:
        df = df.fillna(df.median())
        X = df.drop(columns=target).values
        Y = df[target[0]].values
        E = df[target[1]].values
        return torch.Tensor(X), torch.Tensor(Y), torch.Tensor(E)


def preprocess_fortotal(root, target=['time', 'event'], method='dl'):
    """ target = ['time', 'event']
    method == 'dl' or 'sksurv' """
    assert method in ['dl', 'sksurv']
    assert len(target) == 2
    if isinstance(root, str):
        df = pd.read_csv(root)
    else:
        df = root
    df = df.fillna(df.median())
    if method == 'dl':
        time = df[target[0]].values
        event = df[target[1]].values
        X = df.drop(columns=target).values
        return X, time, event
    elif method == 'sksurv':
        y = Surv.from_dataframe(target[1], target[0], df)
        X = df.drop(columns=target)
        return X, y


def preprocess_fortreat(root, target=['time', 'event', 'treatment'], drop=None, method='bites', treatment=None):
    """ method == 'bites' or 'deepsurv' or 'sksurv' """
    assert method in ['bites', 'deepsurv', 'sksurv', None]
    assert len(target) == 3 or 2
    if isinstance(root, str):
        df = pd.read_csv(root)
    else:
        df = root
    df = df.fillna(df.median())
    if method == 'bites' and treatment is None:
        time = df[target[0]].values
        event = df[target[1]].values
        treatment = df[target[2]].values
        X = df.drop(columns=target).values
        return X, time, event, treatment
    elif method == 'deepsurv' and treatment is not None:
        df_t = df[df[target[2]] == treatment]
        time = df_t[target[0]].values
        event = df_t[target[1]].values
        X = df_t.drop(columns=target).values
        return X, time, event
    elif method == 'sksurv' and treatment is not None:
        df_t = df[df[target[2]] == treatment]
        y = Surv.from_dataframe(target[1], target[0], df_t)
        X = df_t.drop(columns=target)
        return X, y
    elif method is None:
        time = df[target[0]].values
        event = df[target[1]].values
        if drop is not None:
            df = df.drop(columns=drop)
        X = df.drop(columns=target).values
        return X, time, event

def preprocess_forcls(df, target='event', drop=['treatment', 'time']):
    if isinstance(df, str):
        df = pd.read_csv(df)
    df = df.fillna(df.median())
    outcome = df[target].values
    df = df.drop(columns=target)
    X = df.drop(columns=drop).values
    return X, outcome

def trunc_time(root, time_name, event_name, horizon=5 * 12):
    if isinstance(root, str):
        df = pd.read_csv(root)
    else:
        df = root
    for i in range(df.shape[0]):
        if df[time_name][i] > horizon:
            df[event_name][i] = 0
    return df

